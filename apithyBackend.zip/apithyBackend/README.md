## Apithy Test

Prueba de Backend José María Hernandez Estrada

Para instalar los modulos del proyecto
```npm install```

En este proyecto se usaron los siguientes modulos:
    body-parser: "^1.19.0
    compression: "^1.7.4
    cors: "^2.8.5
    ejs: "^3.1.5"
    express: "^4.17.1
    helmet: "^4.2.0
    morgan": "^1.10.0
    mysql": "^2.18.1
    xlsx": "^0.16.8

Para correrlo se deve crear una base de datos en mysql localhost con el nombre, base de datos adjunta en la ruta /micServ/Public
    apithy_db

En la base se deben crear 2 tablas con los siguientes datos:
Nombre: usuario
Columnas: nombre, correo, role

tabla 2
nombre: roles
columnas: id, nombre, codigo

Ejecutar el comando para correr en modo de desarrollo
``` npm run dev ```

Ejecutar el comando para correr en modo de produccion
``` npm run start ```

liga de github
https://github.com/chema013/apithy-test